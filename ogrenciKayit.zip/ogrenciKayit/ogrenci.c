#include "ogrenci.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

ogrenci o1; 

void giris()
{
	int secim = menu(); 
	while( secim!= 0 ) 
	{
		switch(secim ) 
		{
			case 1: yeniKayit(); break; 
			case 2: kayitAra (); break; 
			case 3: kayitSil (); break; 
			case 4: listele (); break; 
			case 5: tumKayitlariSil(); break; 
			
		}
		secim= menu(); 
	}
	
	
 } 
int menu()
{
	printf("\n��RENC� KAYIT UYGULAMASI \n\n") ; 
	printf("[1] Yeni kayit \n") ; 
	printf("[2] Kay�t ara  \n") ; 
	printf("[3] Kay�t sil  \n") ; 
	printf("[4] Listele \n") ; 
	printf("[5] T�m kayatlar� sil  \n") ; 
	printf("[0] �IKI�  \n") ; 
	int secim ; 
	do {
	     printf("\nSe�ene�inizi giriniz [0-5] :  ");
	     secim = getche()-'0';
	     printf("\n");
	  } while (secim<0 || secim>5);
	 
	 return secim; 
	
}
void yeniKayit()
{
	system("cls") ; 
	printf("Yeni kayit icin... \n") ; 
	printf("Numara   : ") ; girisAl(o1.numara ) ; 	
	printf("Ad       : ") ; girisAl(o1.ad) ; 
	printf("Soyad    : ") ; girisAl(o1.soyad) ; 
	printf("Adres    : ") ; girisAl(o1.adres) ; 
	printf("Tel      : ") ; girisAl(o1.tel ) ; 
  	
	  veritabaniKaydet(o1); 
  	
	
}
void kayitAra()
{
	system("cls") ; 
	int sonuc=0; 
	char aranan[20] ; 
 	printf("Ad : "); girisAl(aranan ) ; 
 	
 	FILE *ptr ; 
	if(( ptr= fopen("ogrenciler.txt", "rb") ) == NULL ) 
	{
		printf("Veritabani hatasi ! \n") ; 
		exit(1) ; 
	}
	
	while ( fread ( &o1, sizeof(ogrenci), 1, ptr )  != NULL  ) 
	{
		if( strcmp( aranan, o1.ad ) ==0  ) 
		{
			if(sonuc==0)
			printf("%-20s%-20s%-20s%-20s%-20s\n", "NUMARA", "AD", "SOYAD", "ADRES", "TELEFON") ; 
			printf("%-20s%-20s%-20s%-20s%-20s\n",  o1.numara, o1.ad, o1.soyad, o1.adres, o1.tel ) ; 
			sonuc++;  
			
		} 
		
	}
	fclose(ptr) ;
	if( sonuc==0 ) 
	printf("\n%s isimli kisi kaydi bulunamadi \n" , aranan )   ;
	else
	printf("\n%s isimli kisiden %d adet bulundu \n" , aranan, sonuc  )    ; 
	
}
void kayitSil()
{
	system("cls") ; 
	int sonuc=0; 
	char aranan[20] ; 
 	printf("Numara : "); girisAl(aranan ) ; 
 	
 	FILE *ptr, * yPtr ; 
	if(( ptr= fopen("ogrenciler.txt", "rb") ) == NULL ) 
	{
		printf("Veritabani hatasi ! \n") ; 
		exit(1) ; 
	}
	
	if(( yPtr= fopen("yedek.txt", "wb") ) == NULL ) 
	{
		printf("Veritabani hatasi ! \n") ; 
		exit(1) ; 
	}
	
	
	
	
	while ( fread ( &o1, sizeof(ogrenci), 1, ptr )  != NULL  ) 
	{
		if( strcmp( aranan, o1.numara ) ==0  ) 
		{
			sonuc++; 
		} 
		else
		{
			fwrite ( &o1, sizeof(ogrenci), 1, yPtr ) ; 		
			
		}
		
	}
	fclose(ptr) ;
	fclose(yPtr) ;
	
	remove("ogrenciler.txt") ; 
	rename("yedek.txt", "ogrenciler.txt") ; 
		
	if( sonuc==0 ) 
	printf("\n%s numarali kisi kaydi bulunamadi \n" , aranan )   ;
	else
	printf("\n%s numarali silindi  \n" , aranan, sonuc  )    ; 
	
}
void listele()
{
	system("cls") ; 
	int sonuc=0; 

 	FILE *ptr ; 
	if(( ptr= fopen("ogrenciler.txt", "rb") ) == NULL ) 
	{
		printf("Veritabani hatasi ! \n") ; 
		exit(1) ; 
	}
	
	while ( fread ( &o1, sizeof(ogrenci), 1, ptr )  != NULL  ) 
	{
		 	if(sonuc==0)
		 	printf("%-20s%-20s%-20s%-20s%-20s\n", "NUMARA", "AD", "SOYAD", "ADRES", "TELEFON") ; 
			printf("%-20s%-20s%-20s%-20s%-20s\n",  o1.numara, o1.ad, o1.soyad, o1.adres, o1.tel ) ; 
			sonuc++;  
			
		 
		
	}
	fclose(ptr) ;
	if( sonuc==0 ) 
	printf("\n Liste bos \n" )   ;
	else
	printf("\nListede %d kisi kaydi var  \n",  sonuc  )    ; 
	
	
	
}
void tumKayitlariSil()
{
	system("cls") ; 
	int tercih; 
	printf("Tum kayitlari silmak istediginize emin misiniz [E/H] ? : ") ; tercih= getche(); 
	printf("\n\n") ; 
		
	if( tercih=='e' || tercih=='E') 
	{
		int sonuc = remove("ogrenciler.txt") ; 
		if(sonuc==0) 
		printf("Kayitlar silindi \n") ; 
		else
		printf("Silme islemi basarisiz ! \n") ; 		
	}
	else
	{
		printf("Silme islemi iptal edildi \n") ; 	
	}	
}

void veritabaniKaydet( ogrenci o1  ) 
{
	FILE *ptr ; 
	if(( ptr= fopen("ogrenciler.txt", "ab") ) == NULL ) 
	{
		printf("Veritabani hatasi ! \n") ; 
		exit(1) ; 
	}
	
	fwrite( &o1, sizeof(ogrenci), 1, ptr ) ; 
	fclose(ptr) ; 
	printf("Kayit tamam \n") ; 
 	
}
void girisAl( char *ptr  )
{
	fgets(ptr, 20, stdin) ; 
	int n= strlen(ptr); 
	ptr[n-1] ='\0';
	
}


