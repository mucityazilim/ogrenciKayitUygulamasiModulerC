#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include "ogrenci.h" 

// ogrenci kay�t uygulamas�, mod�ler c yap�s� ile  
 

int main(int argc, char *argv[]) {
	setlocale(LC_ALL, "Turkish") ; 
	
	giris(); 
	
	
	
	return 0;
}
