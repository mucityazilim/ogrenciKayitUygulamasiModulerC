#ifndef _OGRENCI_H
#define _OGRENCI_H

typedef struct Ogrenci {
	char numara[10]; 
	char ad[20]; 
	char soyad[20]; 
	char adres[20]; 
	char tel[20]; 
} ogrenci  ;

void giris(); 
int menu(); 
void yeniKayit();
void kayitAra(); 
void kayitSil(); 
void listele(); 
void tumKayitlariSil(); 
void veritabaniKaydet( ogrenci o1  );
void girisAl ( char * ); 


#endif 
